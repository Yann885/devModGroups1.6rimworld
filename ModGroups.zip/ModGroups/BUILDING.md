# Mod Groups (RimWorld 1.6) — skeleton

Adds a **"Mod Groups"** button to the mod list screen. Click it to open a window where you can:
- Create named groups
- Move any installed mod into a group ("Move to..")
- Expand/collapse each group (the `-`/`+` button on its header)
- Toggle every mod in a group on/off at once, via the group's checkbox

Groups are saved to `Config/ModGroups_ModGroupsSettings.xml` in your RimWorld config folder,
so they persist across every save/playthrough, independent of any specific mod list.

## What's here

```
ModGroups/
  About/About.xml          <- mod metadata RimWorld reads
  ModGroups.csproj         <- build this
  1.6/Assemblies/          <- compiled ModGroups.dll goes here (empty for now)
  Source/                  <- C# source, NOT read by the game itself
    ModGroupsMod.cs
    ModGroupsSettings.cs
    ModGroup.cs
    Patch_PageModsConfig.cs
    Dialog_ModGroups.cs
```

## How to build it

1. Get a copy of `0Harmony.dll` (from the Harmony mod, or wherever you already have one) and
   drop it into `Lib/0Harmony.dll` next to `ModGroups.csproj` — create the `Lib` folder if
   it's not there. This is only used for compiling; the separate Harmony mod (already
   declared as a dependency in About.xml) supplies its own copy to the game at runtime.
2. Open `ModGroups.csproj` (at the root of this folder) in Visual Studio, VS Code, or Rider.
3. Edit the `<RimWorldManagedPath>` line near the top of the .csproj to point at your
   own RimWorld install's `Managed` folder (contains `Assembly-CSharp.dll`, `UnityEngine.*.dll`).
   Typical Steam path:
   `C:\Program Files (x86)\Steam\steamapps\common\RimWorld\RimWorldWin64_Data\Managed`
4. Build (Release). The project is configured to drop `ModGroups.dll` straight into
   `1.6/Assemblies/` (relative to the project file, which sits at the mod root —
   if you ever move `ModGroups.csproj` elsewhere, update `OutputPath` to match).
5. Copy the whole `ModGroups` folder into your RimWorld `Mods` folder
   (or subscribe/point Steam's local mods folder at it), enable it in-game, and
   restart RimWorld.

## Known rough edges (it's a first skeleton, not a polished release)

- **`ModMetaData.Active` setter**: this build assumes it exists publicly (true in recent
  1.5/1.6 builds). If the compiler complains, swap `mod.Active = x;` for
  `ModsConfig.SetActive(mod.PackageId, x);` in `Dialog_ModGroups.cs` — same underlying effect.
- **Button position**: the "Mod Groups" button is placed in the top-right corner of the mod
  list window in `Patch_PageModsConfig.cs`. If it overlaps a vanilla button on your RimWorld
  version, just tweak the `Rect` there.
- **No drag-and-drop** between groups yet — moving a mod is done via the "Move to.." menu.
  Straightforward to add later if you want it.
- The Harmony patch on `Page_ModsConfig.DoWindowContents` uses a **Prefix**, not a Postfix —
  a Postfix here threw `HarmonyException: Patching exception ...` on testing, most likely
  because the original method wraps its body in a try/finally (scroll view cleanup) that a
  tail-inserted Postfix collided with. Prefix inserts before any of that and is safer for
  this particular method.
- `harmony.PatchAll()` is wrapped in try/catch in `ModGroupsMod.cs`, so if a future RimWorld
  update renames or restructures `DoWindowContents`, the mod logs a clear error instead of
  failing to instantiate — check `Player.log` for `[Mod Groups] Failed to apply Harmony patches`.

## Publishing

This folder mixes two audiences: RimWorld itself (which only needs `About/` and the
compiled dll) and future contributors (who need the source). Split it like this:

### Steam Workshop upload — only ship the compiled mod

Include:
- `About/` (About.xml, Preview.png if you add one)
- `1.6/Assemblies/ModGroups.dll` — the **compiled** dll, not the source
- `LoadFolders.xml` if you ever add one

Leave out: `Source/`, `Lib/`, `ModGroups.csproj`, `.gitignore`, `bin/`, `obj/`, this
`README.md`. None of it is read by the game, and shipping the `.csproj`/`Source/`
means anyone can already read your code by unzipping the Workshop item anyway — so
there's no real benefit to including it, just extra download size.

Upload via RimWorld's built-in **Mod Uploader**: enable Dev Mode in Options, then use
the publish button next to the mod in the mod list (or `Steam > Workshop > Upload` from
the dev tools menu). Don't upload manually by editing Steam Cloud files directly.

### GitHub — ship the source, not your personal build config

Include:
- `About/`, `Source/`, `ModGroups.csproj`, `README.md`, `.gitignore`
- An empty `1.6/Assemblies/` and `Lib/` folder (`.gitkeep` only) so the expected
  layout is obvious to a new contributor
- A `LICENSE` file — pick one (MIT is the norm for small RimWorld mods) so people
  know they're allowed to submit PRs/forks

Leave out (the included `.gitignore` already excludes these):
- `bin/`, `obj/` — build artifacts, regenerated on every build
- `Lib/0Harmony.dll` — it's a third-party binary with its own license; don't
  redistribute it, let contributors drop in their own copy (README already explains
  where to get one)
- `1.6/Assemblies/ModGroups.dll` — also just a build artifact of the `Source/` folder;
  regenerated by anyone who clones and builds. (If you specifically want non-programmer
  testers to grab a working build straight from GitHub without compiling, you can
  deliberately commit this one and drop the corresponding `.gitignore` line — that's
  a judgment call, not a hard rule.)
- Also strip the hardcoded personal path in `<RimWorldManagedPath>` in the .csproj
  before publishing — leave it as a placeholder/example so each contributor edits
  their own, rather than shipping your `C:\Program Files (x86)\...` path.

## Next steps if you want to extend it

- Drag-to-reorder mods within/between groups.
- Color-tagging groups (matches the old community request for Fluffy's Mod Manager).
- Export/import a group layout as JSON to share with others.

