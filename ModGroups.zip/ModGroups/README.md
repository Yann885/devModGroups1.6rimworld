# Mod Groups (RimWorld 1.6) — skeleton

Adds a **"Mod Groups"** button to the mod list screen. Click it to open a window where you can:
- Create named groups
- Move any installed mod into a group ("Move to..")
- Expand/collapse each group (the `-`/`+` button on its header)
- Toggle every mod in a group on/off at once, via the group's checkbox

Groups are saved to `Config/ModGroups_ModGroupsSettings.xml` in your RimWorld config folder,
so they persist across every save/playthrough, independent of any specific mod list.

## What's here

```
ModGroups/
  About/About.xml          <- mod metadata RimWorld reads
  ModGroups.csproj         <- build this
  1.6/Assemblies/          <- compiled ModGroups.dll goes here (empty for now)
  Source/                  <- C# source, NOT read by the game itself
    ModGroupsMod.cs
    ModGroupsSettings.cs
    ModGroup.cs
    Patch_PageModsConfig.cs
    Dialog_ModGroups.cs
```

## How to build it

1. Get a copy of `0Harmony.dll` (from the Harmony mod, or wherever you already have one) and
   drop it into `Lib/0Harmony.dll` next to `ModGroups.csproj` — create the `Lib` folder if
   it's not there. This is only used for compiling; the separate Harmony mod (already
   declared as a dependency in About.xml) supplies its own copy to the game at runtime.
2. Open `ModGroups.csproj` (at the root of this folder) in Visual Studio, VS Code, or Rider.
3. Edit the `<RimWorldManagedPath>` line near the top of the .csproj to point at your
   own RimWorld install's `Managed` folder (contains `Assembly-CSharp.dll`, `UnityEngine.*.dll`).
   Typical Steam path:
   `C:\Program Files (x86)\Steam\steamapps\common\RimWorld\RimWorldWin64_Data\Managed`
4. Build (Release). The project is configured to drop `ModGroups.dll` straight into
   `1.6/Assemblies/` (relative to the project file, which sits at the mod root —
   if you ever move `ModGroups.csproj` elsewhere, update `OutputPath` to match).
5. Copy the whole `ModGroups` folder into your RimWorld `Mods` folder
   (or subscribe/point Steam's local mods folder at it), enable it in-game, and
   restart RimWorld.

## Known rough edges (it's a first skeleton, not a polished release)

- **`ModMetaData.Active` setter**: this build assumes it exists publicly (true in recent
  1.5/1.6 builds). If the compiler complains, swap `mod.Active = x;` for
  `ModsConfig.SetActive(mod.PackageId, x);` in `Dialog_ModGroups.cs` — same underlying effect.
- **Button position**: the "Mod Groups" button is placed in the top-right corner of the mod
  list window in `Patch_PageModsConfig.cs`. If it overlaps a vanilla button on your RimWorld
  version, just tweak the `Rect` there.
- **No drag-and-drop** between groups yet — moving a mod is done via the "Move to.." menu.
  Straightforward to add later if you want it.
- The Harmony patch on `Page_ModsConfig.DoWindowContents` uses a **Prefix**, not a Postfix —
  a Postfix here threw `HarmonyException: Patching exception ...` on testing, most likely
  because the original method wraps its body in a try/finally (scroll view cleanup) that a
  tail-inserted Postfix collided with. Prefix inserts before any of that and is safer for
  this particular method.
- `harmony.PatchAll()` is wrapped in try/catch in `ModGroupsMod.cs`, so if a future RimWorld
  update renames or restructures `DoWindowContents`, the mod logs a clear error instead of
  failing to instantiate — check `Player.log` for `[Mod Groups] Failed to apply Harmony patches`.

## Next steps if you want to extend it

- Drag-to-reorder mods within/between groups.
- Color-tagging groups (matches the old community request for Fluffy's Mod Manager).
- Export/import a group layout as JSON to share with others.
