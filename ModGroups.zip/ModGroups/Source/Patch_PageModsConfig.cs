using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Prefix-patches the vanilla mod list window's DoWindowContents. We draw
    /// our button, then shrink the rect (via ref) before the original method
    /// runs, reserving a strip at the top so vanilla content is drawn below
    /// our button instead of on top of it (drawing on top without shrinking
    /// the rect left the button invisible - vanilla draws after us and
    /// covered the same area).
    /// NOTE: if this fails to patch after a RimWorld update, open Page_ModsConfig
    /// in a decompiler (dnSpy/ILSpy) and confirm the method name/signature/param
    /// name below still matches — Ludeon occasionally renames internals between
    /// versions (confirmed: in 1.6.4871 the parameter is "rect", not "inRect").
    /// </summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoWindowContents")]
    public static class Patch_PageModsConfig_DoWindowContents
    {
        // "__0" binds to the original method's first parameter *by position*,
        // not by name. This is what broke last time (Ludeon renamed the param
        // from "inRect" to "rect" between builds) - positional binding survives
        // that kind of rename. It will still break if RimWorld changes the
        // parameter's type or the method's parameter count/order entirely.
        public static void Prefix(ref Rect __0)
        {
            float buttonWidth = 160f;
            float buttonHeight = 32f;
            Rect buttonRect = new Rect(__0.xMax - buttonWidth, __0.yMin, buttonWidth, buttonHeight);

            if (Widgets.ButtonText(buttonRect, "Mod Groups"))
            {
                Find.WindowStack.Add(new Dialog_ModGroups());
            }

            // Reserve the strip we just drew into so vanilla content starts below it.
            __0.yMin += buttonHeight + 6f;
        }
    }
}
