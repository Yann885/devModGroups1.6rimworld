using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Adds group controls above the vanilla mod list. The original RimWorld
    /// page remains responsible for drawing and operating its complete UI.
    /// NOTE: if this fails to patch after a RimWorld update, open Page_ModsConfig
    /// in a decompiler (dnSpy/ILSpy) and confirm the method name/signature/param
    /// name below still matches — Ludeon occasionally renames internals between
    /// versions (confirmed: in 1.6.4871 the parameter is "rect", not "inRect").
    /// </summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoWindowContents")]
    public static class Patch_PageModsConfig_DoWindowContents
    {
        private static bool groupedListsEnabled = true;
        // "__0" binds to the original method's first parameter *by position*,
        // not by name. This is what broke last time (Ludeon renamed the param
        // from "inRect" to "rect" between builds) - positional binding survives
        // that kind of rename. It will still break if RimWorld changes the
        // parameter's type or the method's parameter count/order entirely.
        public static bool Prefix(ref Rect __0)
        {
            float buttonWidth = 150f;
            float buttonHeight = 32f;
            float raiseAboveFrame = 10f; // pokes a bit above the window's content edge
            Rect toggleRect = new Rect(__0.xMax - buttonWidth * 2f - 6f, __0.yMin - raiseAboveFrame, buttonWidth, buttonHeight);
            Rect manageRect = new Rect(__0.xMax - buttonWidth, __0.yMin - raiseAboveFrame, buttonWidth, buttonHeight);

            if (Widgets.ButtonText(toggleRect, groupedListsEnabled ? "MG_GroupsOn".Translate() : "MG_GroupsOff".Translate()))
            {
                groupedListsEnabled = !groupedListsEnabled;
            }
            if (Widgets.ButtonText(manageRect, "MG_ManageGroups".Translate()))
            {
                Find.WindowStack.Add(new Dialog_ModGroups());
            }

            // Reserve the strip so vanilla content remains unobstructed.
            __0.yMin += buttonHeight + 6f - raiseAboveFrame;
            return true;
        }

        public static bool GroupedListsEnabled => groupedListsEnabled;

        public static ModGroup FindGroup(string packageId)
        {
            var settings = ModGroupsMod.Settings;
            return settings?.groups?.FirstOrDefault(g => g.packageIds != null && g.packageIds.Contains(packageId));
        }
    }

    /// <summary>Draws expandable group headers inside RimWorld's native mod columns.</summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoModList")]
    public static class Patch_PageModsConfig_DoModList
    {
        private sealed class GroupModsEntry
        {
            public ModGroup Group;
            public List<ModMetaData> Mods;
        }

        private static readonly System.Reflection.MethodInfo DrawVanillaRow = AccessTools.Method(typeof(Page_ModsConfig), "DoModRow");
        private static readonly System.Reflection.FieldInfo ModRowHeight = AccessTools.Field(typeof(Page_ModsConfig), "ModRowHeight");
        private static readonly System.Reflection.FieldInfo MetaRowHeight = AccessTools.Field(typeof(Page_ModsConfig), "MetaRowHeight");
        private static readonly System.Reflection.FieldInfo InactiveGroupId = AccessTools.Field(typeof(Page_ModsConfig), "inactiveGroupId");
        private static readonly Dictionary<int, bool> ungroupedCollapsedByList = new Dictionary<int, bool>();
        private static bool sharedGroupsCollapsedActive;
        private static bool sharedGroupsCollapsedInactive;

        public static bool Prefix(Page_ModsConfig __instance, Rect __0, List<ModMetaData> __1, ref Vector2 __2, ref int __3)
        {
            if (!Patch_PageModsConfig_DoWindowContents.GroupedListsEnabled)
                return true;

            float rowHeight = ModRowHeight == null ? 28f : (float)ModRowHeight.GetValue(null);
            float headerHeight = MetaRowHeight == null ? rowHeight : (float)MetaRowHeight.GetValue(null);
            var source = __1 ?? new List<ModMetaData>();
            // RimWorld's list identifier is not stable across all 1.6 builds.
            // The list itself is the reliable signal: enabled/disabled columns
            // contain mods with the corresponding Active state.
            bool inactive = source.Count > 0
                ? source.All(mod => !mod.Active)
                : InactiveGroupId != null && __3 == (int)InactiveGroupId.GetValue(__instance);
            var settings = ModGroupsMod.Settings;
            var membershipsByPackageId = settings.groups
                .SelectMany(group => (group.packageIds ?? new List<string>()).Select(packageId => new { packageId, group }))
                .GroupBy(item => item.packageId)
                .ToDictionary(items => items.Key, items => items.Select(item => item.group).ToList());
            var sharedEntries = !inactive
                ? settings.groups
                    .Select(group => new GroupModsEntry
                    {
                        Group = group,
                        Mods = source.Where(mod => membershipsByPackageId.TryGetValue(mod.PackageId, out var memberships)
                            && memberships.Count > 1 && memberships.Contains(group)).ToList()
                    })
                    .Where(entry => entry.Mods.Count > 0)
                    .ToList()
                : new List<GroupModsEntry>();
            var sharedPackageIds = new HashSet<string>(sharedEntries.SelectMany(entry => entry.Mods).Select(mod => mod.PackageId));
            var visibleGroups = settings.groups
                .Select(group => new GroupModsEntry
                {
                    Group = group,
                    // In the enabled column shared mods live in the special
                    // shared section. In the disabled column, keep the full
                    // membership in every group so small groups are not
                    // swallowed by whichever group happens to come first.
                    Mods = source.Where(mod => group.packageIds != null
                        && group.packageIds.Contains(mod.PackageId)
                        && (inactive || !sharedPackageIds.Contains(mod.PackageId))).ToList()
                })
                .Where(entry => entry.Mods.Count > 0)
                .ToList();
            var groupedIds = new HashSet<string>(visibleGroups.SelectMany(x => x.Mods).Select(m => m.PackageId));
            groupedIds.UnionWith(sharedPackageIds);
            var ungrouped = source.Where(m => !groupedIds.Contains(m.PackageId)).ToList();
            float contentHeight = headerHeight + ungrouped.Count * rowHeight;
            foreach (var entry in visibleGroups)
                contentHeight += headerHeight + (IsCollapsed(entry.Group, inactive) ? 0f : entry.Mods.Count * rowHeight);
            if (sharedEntries.Count > 0)
            {
                contentHeight += headerHeight;
                if (!AreSharedGroupsCollapsed(inactive))
                {
                    foreach (var entry in sharedEntries)
                        contentHeight += headerHeight + (IsSharedGroupCollapsed(entry.Group, inactive) ? 0f : entry.Mods.Count * rowHeight);
                }
            }

            Rect viewRect = new Rect(0f, 0f, __0.width - 16f, contentHeight + 8f);
            Widgets.BeginScrollView(__0, ref __2, viewRect);
            float y = 0f;

            if (sharedEntries.Count > 0)
            {
                y = DrawSharedGroupsHeader(viewRect.width, y, headerHeight, sharedPackageIds.Count, inactive);
                if (!AreSharedGroupsCollapsed(inactive))
                {
                    foreach (var entry in sharedEntries)
                    {
                        y = DrawGroupHeader(viewRect.width, y, headerHeight, entry.Group, entry.Mods, inactive, true);
                        if (!IsSharedGroupCollapsed(entry.Group, inactive))
                            DrawRows(__instance, viewRect.width, ref y, rowHeight, entry.Mods, source);
                    }
                }
            }

            foreach (var entry in visibleGroups)
            {
                y = DrawGroupHeader(viewRect.width, y, headerHeight, entry.Group, entry.Mods, inactive, false);
                if (!IsCollapsed(entry.Group, inactive))
                    DrawRows(__instance, viewRect.width, ref y, rowHeight, entry.Mods, source);
            }

            bool ungroupedCollapsed = ungroupedCollapsedByList.ContainsKey(__3) && ungroupedCollapsedByList[__3];
            y = DrawUngroupedHeader(viewRect.width, y, headerHeight, ungrouped.Count, ungroupedCollapsed, __3);
            if (!ungroupedCollapsed)
                DrawRows(__instance, viewRect.width, ref y, rowHeight, ungrouped, source);

            Widgets.EndScrollView();
            return false;
        }

        private static bool IsCollapsed(ModGroup group, bool inactive)
        {
            return inactive ? group.collapsedInactive : group.collapsedActive;
        }

        private static bool IsSharedGroupCollapsed(ModGroup group, bool inactive)
        {
            return inactive ? group.collapsedSharedInactive : group.collapsedSharedActive;
        }

        private static bool AreSharedGroupsCollapsed(bool inactive)
        {
            return inactive ? sharedGroupsCollapsedInactive : sharedGroupsCollapsedActive;
        }

        private static float DrawGroupHeader(float width, float y, float height, ModGroup group, List<ModMetaData> mods, bool inactive, bool shared)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, Dialog_ModGroups.GroupColor(group));
            bool collapsed = shared ? IsSharedGroupCollapsed(group, inactive) : IsCollapsed(group, inactive);
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
            {
                if (shared && inactive) group.collapsedSharedInactive = !collapsed;
                else if (shared) group.collapsedSharedActive = !collapsed;
                else if (inactive) group.collapsedInactive = !collapsed;
                else group.collapsedActive = !collapsed;
                ModGroupsMod.Settings.Save();
            }
            bool allActive = mods.Count > 0 && mods.All(m => m.Active);
            bool newState = allActive;
            Widgets.Checkbox(new Vector2(28f, y + (height - 18f) / 2f), ref newState);
            if (newState != allActive)
            {
                foreach (var mod in mods) mod.Active = newState;
                ModsConfig.Save();
            }
            string headerKey = inactive ? "MG_GroupHeaderInactive" : "MG_GroupHeaderActive";
            Widgets.Label(new Rect(52f, y, width - 54f, height), headerKey.Translate(group.name, mods.Count));
            return y + height;
        }

        private static float DrawSharedGroupsHeader(float width, float y, float height, int count, bool inactive)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, new Color(0.27f, 0.20f, 0.37f, 0.78f));
            bool collapsed = AreSharedGroupsCollapsed(inactive);
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
            {
                if (inactive) sharedGroupsCollapsedInactive = !collapsed;
                else sharedGroupsCollapsedActive = !collapsed;
            }
            Widgets.Label(new Rect(30f, y, width - 32f, height), "MG_SharedGroupsHeader".Translate(count));
            return y + height;
        }

        private static float DrawUngroupedHeader(float width, float y, float height, int count, bool collapsed, int listId)
        {
            Rect rect = new Rect(0f, y, width, height);
            Widgets.DrawBoxSolid(rect, new Color(0.15f, 0.15f, 0.15f, 0.65f));
            if (Widgets.ButtonText(new Rect(2f, y + 1f, 22f, height - 2f), collapsed ? "+" : "-"))
                ungroupedCollapsedByList[listId] = !collapsed;
            Widgets.Label(new Rect(30f, y, width - 32f, height), "MG_UngroupedCount".Translate(count));
            return y + height;
        }

        private static void DrawRows(Page_ModsConfig page, float width, ref float y, float rowHeight, List<ModMetaData> mods, List<ModMetaData> fullList)
        {
            foreach (var mod in mods)
            {
                int index = fullList.IndexOf(mod);
                Rect rowRect = new Rect(0f, y, width, rowHeight);
                DrawVanillaRow.Invoke(page, new object[] { rowRect, mod, fullList, index, false });
                y += rowHeight;
            }
        }
    }

    /// <summary>Lets the selected mod be assigned directly from its native info panel.</summary>
    [HarmonyPatch(typeof(Page_ModsConfig), "DoModInfo")]
    public static class Patch_PageModsConfig_DoModInfo
    {
        public static void Postfix(Rect __0, ModMetaData __1)
        {
            if (__1 == null) return;
            float y = __0.yMax - 31f;
            Rect groupButton = new Rect(__0.xMin, y, Math.Min(165f, __0.width), 30f);
            var currentGroup = Patch_PageModsConfig_DoWindowContents.FindGroup(__1.PackageId);
            string label = currentGroup == null ? "MG_AddToGroup".Translate() : "MG_GroupLabel".Translate(currentGroup.name);
            if (Widgets.ButtonText(groupButton, label))
            {
                var settings = ModGroupsMod.Settings;
                var options = new List<FloatMenuOption>();
                options.Add(new FloatMenuOption("MG_NoGroup".Translate(), () =>
                {
                    foreach (var group in settings.groups) group.packageIds.Remove(__1.PackageId);
                    settings.Save();
                }));
                foreach (var group in settings.groups)
                {
                    var selectedGroup = group;
                    options.Add(new FloatMenuOption(group.name, () =>
                    {
                        foreach (var other in settings.groups) other.packageIds.Remove(__1.PackageId);
                        if (!selectedGroup.packageIds.Contains(__1.PackageId)) selectedGroup.packageIds.Add(__1.PackageId);
                        if (!settings.knownPackageIds.Contains(__1.PackageId)) settings.knownPackageIds.Add(__1.PackageId);
                        settings.Save();
                    }));
                }
                if (settings.groups.Count == 0) options.Add(new FloatMenuOption("MG_CreateGroupManage".Translate(), null));
                Find.WindowStack.Add(new FloatMenu(options));
            }
        }
    }
}
