using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Custom window listing every installed mod, organized into user-defined,
    /// collapsible groups. Opened via the "Mod Groups" button injected into the
    /// vanilla mod list page (see Patch_PageModsConfig).
    ///
    /// NOTE on ModMetaData.Active: this build assumes it has a public setter
    /// (true in most recent RimWorld versions). If your compiler complains,
    /// replace "mod.Active = x;" with "ModsConfig.SetActive(mod.PackageId, x);"
    /// which is the underlying API this normally calls into.
    /// </summary>
    public class Dialog_ModGroups : Window
    {
        private Vector2 scrollPosition = Vector2.zero;
        private float viewHeight = 1000f;
        private string newGroupName = "";
        private string renamingGroupName = null;
        private string renameBuffer = "";
        private bool ungroupedCollapsed = false;
        private bool newModsCollapsed = false;
        private readonly HashSet<string> selected = new HashSet<string>();

        public override Vector2 InitialSize => new Vector2(700f, 800f);

        public Dialog_ModGroups()
        {
            doCloseButton = true;
            doCloseX = true;
            forcePause = true;
            absorbInputAroundWindow = true;

            // First time this window is ever opened, baseline "known" mods to
            // everything currently installed, so nothing shows up as "new"
            // retroactively - only mods that appear from now on will.
            var settings = ModGroupsMod.Settings;
            if (settings.knownPackageIds.Count == 0)
            {
                settings.knownPackageIds.AddRange(ModLister.AllInstalledMods.Select(m => m.PackageId));
                settings.Save();
            }
        }

        public override void DoWindowContents(Rect inRect)
        {
            var settings = ModGroupsMod.Settings;

            // --- row 1: create a new group ---
            Rect nameFieldRect = new Rect(0f, 0f, inRect.width - 140f, 30f);
            Rect addButtonRect = new Rect(inRect.width - 130f, 0f, 130f, 30f);

            newGroupName = Widgets.TextField(nameFieldRect, newGroupName);
            if (Widgets.ButtonText(addButtonRect, "New group") && !string.IsNullOrWhiteSpace(newGroupName))
            {
                if (!settings.groups.Any(g => g.name == newGroupName))
                {
                    settings.groups.Add(new ModGroup(newGroupName));
                    settings.Save();
                }
                newGroupName = "";
            }

            // --- row 2: bulk actions for whatever's currently ticked ---
            Rect selectedLabelRect = new Rect(0f, 36f, inRect.width - 300f, 30f);
            Widgets.Label(selectedLabelRect, selected.Count > 0 ? $"Selected: {selected.Count}" : "Tick mods below to move several at once");

            Rect bulkMoveRect = new Rect(inRect.width - 290f, 36f, 140f, 30f);
            Rect clearRect = new Rect(inRect.width - 140f, 36f, 140f, 30f);

            GUI.enabled = selected.Count > 0;
            if (Widgets.ButtonText(bulkMoveRect, "Add selected to.."))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        foreach (var pkgId in selected)
                        {
                            if (!g.packageIds.Contains(pkgId))
                            {
                                g.packageIds.Add(pkgId);
                            }
                            if (!settings.knownPackageIds.Contains(pkgId))
                            {
                                settings.knownPackageIds.Add(pkgId);
                            }
                        }
                        settings.Save();
                        selected.Clear();
                    }));
                }
                options.Add(new FloatMenuOption("(Remove from all groups)", () =>
                {
                    foreach (var g in settings.groups)
                    {
                        foreach (var pkgId in selected)
                        {
                            g.packageIds.Remove(pkgId);
                        }
                    }
                    settings.Save();
                    selected.Clear();
                }));
                if (settings.groups.Count == 0)
                {
                    options.Insert(0, new FloatMenuOption("(Create a group first)", null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }
            if (Widgets.ButtonText(clearRect, "Clear selection"))
            {
                selected.Clear();
            }
            GUI.enabled = true;

            // --- row 3: collapse/expand every group at once ---
            Rect hideGroupedRect = new Rect(0f, 72f, 220f, 30f);
            Rect expandAllRect = new Rect(230f, 72f, 140f, 30f);

            if (Widgets.ButtonText(hideGroupedRect, "Hide grouped mods"))
            {
                foreach (var g in settings.groups)
                {
                    if (!g.pinned) g.collapsed = true;
                }
                settings.Save();
            }
            if (Widgets.ButtonText(expandAllRect, "Expand all"))
            {
                foreach (var g in settings.groups)
                {
                    g.collapsed = false;
                }
                settings.Save();
            }

            // --- scrollable list: new mods (if any) + groups + ungrouped ---
            Rect listOuter = new Rect(0f, 110f, inRect.width, inRect.height - 110f);
            Rect listInner = new Rect(0f, 0f, listOuter.width - 16f, viewHeight);

            Widgets.BeginScrollView(listOuter, ref scrollPosition, listInner);

            float curY = 0f;
            var allMods = ModLister.AllInstalledMods.OrderBy(m => m.Name).ToList();
            var groupedIds = new HashSet<string>(settings.groups.SelectMany(g => g.packageIds));

            var newMods = allMods.Where(m => !settings.knownPackageIds.Contains(m.PackageId)).ToList();
            if (newMods.Count > 0)
            {
                curY = DrawNewMods(listInner.width, curY, newMods, settings);
            }

            foreach (var group in settings.groups.ToList())
            {
                curY = DrawGroup(listInner.width, curY, group, allMods, settings);
            }

            var ungrouped = allMods.Where(m => !groupedIds.Contains(m.PackageId)).ToList();
            curY = DrawUngrouped(listInner.width, curY, ungrouped, settings);

            viewHeight = curY + 20f;
            Widgets.EndScrollView();
        }

        private float DrawNewMods(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.45f, 0.32f, 0.05f, 0.6f)); // amber - stands out

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, newModsCollapsed ? "+" : "-"))
            {
                newModsCollapsed = !newModsCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f - 150f, 30f);
            Widgets.Label(nameRect, $"New mods ({mods.Count})");

            Rect markSeenRect = new Rect(width - 145f, y + 1f, 145f, 28f);
            if (Widgets.ButtonText(markSeenRect, "Mark all as seen"))
            {
                foreach (var mod in mods)
                {
                    if (!settings.knownPackageIds.Contains(mod.PackageId))
                    {
                        settings.knownPackageIds.Add(mod.PackageId);
                    }
                }
                settings.Save();
            }

            y += 32f;

            if (!newModsCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawGroup(float width, float y, ModGroup group, List<ModMetaData> allMods, ModGroupsSettings settings)
        {
            var groupMods = allMods.Where(m => group.packageIds.Contains(m.PackageId)).ToList();

            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.22f, 0.22f, 0.22f, 0.6f));

            // Collapse / expand toggle
            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, group.collapsed ? "+" : "-"))
            {
                group.collapsed = !group.collapsed;
                settings.Save();
            }

            // Enable/disable every mod in this group at once
            Rect checkRect = new Rect(32f, y + 6f, 18f, 18f);
            bool allActive = groupMods.Count > 0 && groupMods.All(m => m.Active);
            bool newState = allActive;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newState);
            if (newState != allActive)
            {
                foreach (var m in groupMods)
                {
                    m.Active = newState;
                }
                ModsConfig.Save();
            }

            Rect pinRect = new Rect(width - 210f, y + 1f, 46f, 28f);
            Rect renameRect = new Rect(width - 160f, y + 1f, 52f, 28f);
            Rect deleteRect = new Rect(width - 104f, y + 1f, 50f, 28f);
            Rect confirmRect = new Rect(width - 50f, y + 1f, 50f, 28f);
            Rect nameRect = new Rect(56f, y, width - 56f - 212f, 30f);

            if (Widgets.ButtonText(pinRect, group.pinned ? "Unpin" : "Pin"))
            {
                group.pinned = !group.pinned;
                settings.Save();
            }

            if (renamingGroupName == group.name)
            {
                renameBuffer = Widgets.TextField(nameRect, renameBuffer);
                if (Widgets.ButtonText(confirmRect, "OK"))
                {
                    if (!string.IsNullOrWhiteSpace(renameBuffer))
                    {
                        group.name = renameBuffer;
                        settings.Save();
                    }
                    renamingGroupName = null;
                }
            }
            else
            {
                Widgets.Label(nameRect, (group.pinned ? "* " : "") + $"{group.name} ({groupMods.Count})");
                if (Widgets.ButtonText(renameRect, "Rename"))
                {
                    renamingGroupName = group.name;
                    renameBuffer = group.name;
                }
                if (Widgets.ButtonText(deleteRect, "Delete"))
                {
                    settings.groups.Remove(group);
                    settings.Save();
                }
            }

            y += 32f;

            if (!group.collapsed)
            {
                foreach (var mod in groupMods.OrderBy(m => m.Name))
                {
                    y = DrawModRow(width, y, mod, group, settings);
                }
            }

            return y + 8f;
        }

        private float DrawUngrouped(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.15f, 0.15f, 0.15f, 0.5f));

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, ungroupedCollapsed ? "+" : "-"))
            {
                ungroupedCollapsed = !ungroupedCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f, 30f);
            Widgets.Label(nameRect, $"Ungrouped ({mods.Count})");

            y += 32f;

            if (!ungroupedCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawModRow(float width, float y, ModMetaData mod, ModGroup currentGroup, ModGroupsSettings settings)
        {
            Rect rowRect = new Rect(24f, y, width - 24f, 28f);

            // Selection checkbox (for bulk "Add selected to..")
            Rect selectRect = new Rect(rowRect.x, rowRect.y + 5f, 18f, 18f);
            bool isSelected = selected.Contains(mod.PackageId);
            bool newSelected = isSelected;
            Widgets.Checkbox(new Vector2(selectRect.x, selectRect.y), ref newSelected);
            if (newSelected != isSelected)
            {
                if (newSelected) selected.Add(mod.PackageId);
                else selected.Remove(mod.PackageId);
            }

            // Active/enabled checkbox
            Rect checkRect = new Rect(rowRect.x + 24f, rowRect.y + 5f, 18f, 18f);
            bool active = mod.Active;
            bool newActive = active;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newActive);
            if (newActive != active)
            {
                mod.Active = newActive;
                ModsConfig.Save();
            }

            Rect labelRect = new Rect(rowRect.x + 48f, rowRect.y, rowRect.width - 48f - 90f, 28f);
            Widgets.Label(labelRect, mod.Name);

            Rect moveRect = new Rect(rowRect.xMax - 84f, rowRect.y + 1f, 84f, 26f);
            if (Widgets.ButtonText(moveRect, "Add to.."))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    if (g.packageIds.Contains(mod.PackageId)) continue; // already in this group
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        g.packageIds.Add(mod.PackageId);
                        if (!settings.knownPackageIds.Contains(mod.PackageId))
                        {
                            settings.knownPackageIds.Add(mod.PackageId);
                        }
                        settings.Save();
                    }));
                }
                if (currentGroup != null)
                {
                    options.Add(new FloatMenuOption("(Remove from this group)", () =>
                    {
                        currentGroup.packageIds.Remove(mod.PackageId);
                        settings.Save();
                    }));
                }
                if (options.Count == 0)
                {
                    options.Add(new FloatMenuOption("(Create a group first)", null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }

            return y + 28f;
        }
    }
}
