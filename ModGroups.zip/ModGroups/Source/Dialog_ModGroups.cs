using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Custom window listing every installed mod, organized into user-defined,
    /// collapsible groups. Opened via the "Mod Groups" button injected into the
    /// vanilla mod list page (see Patch_PageModsConfig).
    ///
    /// NOTE on ModMetaData.Active: this build assumes it has a public setter
    /// (true in most recent RimWorld versions). If your compiler complains,
    /// replace "mod.Active = x;" with "ModsConfig.SetActive(mod.PackageId, x);"
    /// which is the underlying API this normally calls into.
    /// </summary>
    public class Dialog_ModGroups : Window
    {
        private Vector2 scrollPosition = Vector2.zero;
        private float viewHeight = 1000f;
        private string newGroupName = "";
        private string renamingGroupName = null;
        private string renameBuffer = "";
        private bool ungroupedCollapsed = false;
        private bool newModsCollapsed = false;
        private readonly HashSet<string> selected = new HashSet<string>();
        private List<ModGroup> originalGroups;
        private List<string> originalKnownPackageIds;
        private Dictionary<string, bool> originalActiveStates;
        private bool applied;
        private readonly bool integratedMode;
        private string searchText = "";

        private static readonly string[] GroupColorHexes =
        {
            "#383838", "#8F3434", "#A45E22", "#8A7820", "#397344",
            "#28777A", "#315F9A", "#67458C", "#984D79", "#777777"
        };

        private static readonly string[] GroupColorNames =
        {
            "MG_ColorGray", "MG_ColorRed", "MG_ColorOrange", "MG_ColorYellow", "MG_ColorGreen",
            "MG_ColorTeal", "MG_ColorBlue", "MG_ColorPurple", "MG_ColorPink", "MG_ColorLightGray"
        };

        public override Vector2 InitialSize => new Vector2(960f, 700f);

        public Dialog_ModGroups() : this(false)
        {
        }

        public Dialog_ModGroups(bool integratedMode)
        {
            this.integratedMode = integratedMode;
            doCloseButton = true;
            doCloseX = true;
            forcePause = true;
            absorbInputAroundWindow = true;

            // First time this window is ever opened, baseline "known" mods to
            // everything currently installed, so nothing shows up as "new"
            // retroactively - only mods that appear from now on will.
            var settings = ModGroupsMod.Settings;
            if (settings.knownPackageIds.Count == 0)
            {
                settings.knownPackageIds.AddRange(ModLister.AllInstalledMods.Select(m => m.PackageId));
                settings.Save();
            }

            originalGroups = CloneGroups(settings.groups);
            originalKnownPackageIds = new List<string>(settings.knownPackageIds);
            originalActiveStates = ModLister.AllInstalledMods.ToDictionary(m => m.PackageId, m => m.Active);
        }

        public override void DoWindowContents(Rect inRect)
        {
            var settings = ModGroupsMod.Settings;

            // --- row 1: create a new group ---
            Rect nameFieldRect = new Rect(0f, 0f, inRect.width - (integratedMode ? 140f : 356f), 30f);
            Rect addButtonRect = new Rect(inRect.width - (integratedMode ? 130f : 350f), 0f, integratedMode ? 130f : 112f, 30f);

            newGroupName = Widgets.TextField(nameFieldRect, newGroupName);
            if (Widgets.ButtonText(addButtonRect, "MG_NewGroup".Translate()) && !string.IsNullOrWhiteSpace(newGroupName))
            {
                if (!settings.groups.Any(g => g.name == newGroupName))
                {
                    settings.groups.Add(new ModGroup(newGroupName));
                    settings.Save();
                }
                newGroupName = "";
            }

            if (!integratedMode && Widgets.ButtonText(new Rect(inRect.width - 232f, 0f, 112f, 30f), "MG_Apply".Translate()))
            {
                settings.Save();
                applied = true;
                Close();
            }
            if (!integratedMode && Widgets.ButtonText(new Rect(inRect.width - 114f, 0f, 114f, 30f), "MG_Cancel".Translate()))
            {
                RestoreOriginalState(settings);
                applied = true;
                Close();
            }

            if (integratedMode)
            {
                Rect searchLabelRect = new Rect(0f, 36f, 64f, 30f);
                Widgets.Label(searchLabelRect, "MG_Search".Translate());
                searchText = Widgets.TextField(new Rect(68f, 36f, Math.Min(280f, inRect.width - 80f), 30f), searchText);
            }

            // --- row 2: bulk actions for whatever's currently ticked ---
            float actionY = integratedMode ? 72f : 36f;
            Rect selectedLabelRect = new Rect(0f, actionY, inRect.width - 340f, 30f);
            Widgets.Label(selectedLabelRect, selected.Count > 0 ? "MG_SelectedCount".Translate(selected.Count) : "MG_TickMods".Translate());

            Rect bulkMoveRect = new Rect(inRect.width - 330f, actionY, 175f, 30f);
            Rect clearRect = new Rect(inRect.width - 150f, actionY, 150f, 30f);

            GUI.enabled = selected.Count > 0;
            if (Widgets.ButtonText(bulkMoveRect, "MG_AddSelected".Translate()))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        foreach (var pkgId in selected)
                        {
                            if (!g.packageIds.Contains(pkgId))
                            {
                                g.packageIds.Add(pkgId);
                            }
                            if (!settings.knownPackageIds.Contains(pkgId))
                            {
                                settings.knownPackageIds.Add(pkgId);
                            }
                        }
                        settings.Save();
                        selected.Clear();
                    }));
                }
                options.Add(new FloatMenuOption("MG_RemoveAllGroups".Translate(), () =>
                {
                    foreach (var g in settings.groups)
                    {
                        foreach (var pkgId in selected)
                        {
                            g.packageIds.Remove(pkgId);
                        }
                    }
                    settings.Save();
                    selected.Clear();
                }));
                if (settings.groups.Count == 0)
                {
                    options.Insert(0, new FloatMenuOption("MG_CreateGroupFirst".Translate(), null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }
            if (Widgets.ButtonText(clearRect, "MG_ClearSelection".Translate()))
            {
                selected.Clear();
            }
            GUI.enabled = true;

            // --- row 3: collapse/expand every group at once ---
            float groupActionY = actionY + 36f;
            Rect hideGroupedRect = new Rect(0f, groupActionY, 220f, 30f);
            Rect expandAllRect = new Rect(230f, groupActionY, 140f, 30f);

            if (Widgets.ButtonText(hideGroupedRect, "MG_HideGrouped".Translate()))
            {
                foreach (var g in settings.groups)
                {
                    if (!g.pinned)
                    {
                        g.collapsed = true;
                        g.collapsedActive = true;
                        g.collapsedInactive = true;
                    }
                }
                settings.Save();
            }
            if (Widgets.ButtonText(expandAllRect, "MG_ExpandAll".Translate()))
            {
                foreach (var g in settings.groups)
                {
                    g.collapsed = false;
                    g.collapsedActive = false;
                    g.collapsedInactive = false;
                }
                settings.Save();
            }

            // --- scrollable list: new mods (if any) + groups + ungrouped ---
            float listStartY = groupActionY + 38f;
            Rect listOuter = new Rect(0f, listStartY, inRect.width, inRect.height - listStartY);
            Rect listInner = new Rect(0f, 0f, listOuter.width - 16f, viewHeight);

            Widgets.BeginScrollView(listOuter, ref scrollPosition, listInner);

            float curY = 0f;
            var allMods = ModLister.AllInstalledMods
                .Where(m => string.IsNullOrWhiteSpace(searchText) || m.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 || m.PackageId.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                .OrderBy(m => m.Name).ToList();
            var groupedIds = new HashSet<string>(settings.groups.SelectMany(g => g.packageIds));

            var newMods = allMods.Where(m => !settings.knownPackageIds.Contains(m.PackageId)).ToList();
            if (newMods.Count > 0)
            {
                curY = DrawNewMods(listInner.width, curY, newMods, settings);
            }

            foreach (var group in settings.groups.ToList())
            {
                curY = DrawGroup(listInner.width, curY, group, allMods, settings);
            }

            var ungrouped = allMods.Where(m => !groupedIds.Contains(m.PackageId)).ToList();
            curY = DrawUngrouped(listInner.width, curY, ungrouped, settings);

            viewHeight = curY + 20f;
            Widgets.EndScrollView();
        }

        public override void PostClose()
        {
            if (!applied)
            {
                RestoreOriginalState(ModGroupsMod.Settings);
            }
            base.PostClose();
        }

        private void RestoreOriginalState(ModGroupsSettings settings)
        {
            settings.groups = CloneGroups(originalGroups);
            settings.knownPackageIds = new List<string>(originalKnownPackageIds);
            foreach (var mod in ModLister.AllInstalledMods)
            {
                bool originalActive;
                if (originalActiveStates.TryGetValue(mod.PackageId, out originalActive) && mod.Active != originalActive)
                {
                    mod.Active = originalActive;
                }
            }
            ModsConfig.Save();
            settings.Save();
        }

        private static List<ModGroup> CloneGroups(List<ModGroup> groups)
        {
            return groups.Select(group => new ModGroup(group.name)
            {
                packageIds = new List<string>(group.packageIds ?? new List<string>()),
                collapsed = group.collapsed,
                collapsedActive = group.collapsedActive,
                collapsedInactive = group.collapsedInactive,
                pinned = group.pinned,
                colorHex = group.colorHex
            }).ToList();
        }

        private float DrawNewMods(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.45f, 0.32f, 0.05f, 0.6f)); // amber - stands out

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, newModsCollapsed ? "+" : "-"))
            {
                newModsCollapsed = !newModsCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f - 150f, 30f);
            Widgets.Label(nameRect, "MG_NewModsCount".Translate(mods.Count));

            Rect markSeenRect = new Rect(width - 145f, y + 1f, 145f, 28f);
            if (Widgets.ButtonText(markSeenRect, "MG_MarkAllSeen".Translate()))
            {
                foreach (var mod in mods)
                {
                    if (!settings.knownPackageIds.Contains(mod.PackageId))
                    {
                        settings.knownPackageIds.Add(mod.PackageId);
                    }
                }
                settings.Save();
            }

            y += 32f;

            if (!newModsCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawGroup(float width, float y, ModGroup group, List<ModMetaData> allMods, ModGroupsSettings settings)
        {
            var groupMods = allMods.Where(m => group.packageIds.Contains(m.PackageId)).ToList();

            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, GroupColor(group));

            // Collapse / expand toggle
            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, group.collapsed ? "+" : "-"))
            {
                group.collapsed = !group.collapsed;
                group.collapsedActive = group.collapsed;
                group.collapsedInactive = group.collapsed;
                settings.Save();
            }

            // Enable/disable every mod in this group at once
            Rect checkRect = new Rect(32f, y + 6f, 18f, 18f);
            bool allActive = groupMods.Count > 0 && groupMods.All(m => m.Active);
            bool newState = allActive;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newState);
            if (newState != allActive)
            {
                foreach (var m in groupMods)
                {
                    m.Active = newState;
                }
                ModsConfig.Save();
            }

            Rect colorRect = new Rect(width - 398f, y + 1f, 66f, 28f);
            Rect pinRect = new Rect(width - 328f, y + 1f, 80f, 28f);
            Rect renameRect = new Rect(width - 244f, y + 1f, 108f, 28f);
            Rect deleteRect = new Rect(width - 132f, y + 1f, 76f, 28f);
            Rect confirmRect = new Rect(width - 52f, y + 1f, 52f, 28f);
            Rect nameRect = new Rect(56f, y, width - 56f - 402f, 30f);

            if (Widgets.ButtonText(colorRect, "MG_Color".Translate()))
            {
                var colorOptions = new List<FloatMenuOption>();
                for (int i = 0; i < GroupColorHexes.Length; i++)
                {
                    string colorHex = GroupColorHexes[i];
                    string colorName = GroupColorNames[i].Translate();
                    colorOptions.Add(new FloatMenuOption(colorName, () =>
                    {
                        group.colorHex = colorHex;
                        settings.Save();
                    }));
                }
                Find.WindowStack.Add(new FloatMenu(colorOptions));
            }

            if (Widgets.ButtonText(pinRect, group.pinned ? "MG_Unpin".Translate() : "MG_Pin".Translate()))
            {
                group.pinned = !group.pinned;
                settings.Save();
            }

            if (renamingGroupName == group.name)
            {
                renameBuffer = Widgets.TextField(nameRect, renameBuffer);
                if (Widgets.ButtonText(confirmRect, "MG_OK".Translate()))
                {
                    if (!string.IsNullOrWhiteSpace(renameBuffer))
                    {
                        group.name = renameBuffer;
                        settings.Save();
                    }
                    renamingGroupName = null;
                }
            }
            else
            {
                Widgets.Label(nameRect, "MG_GroupNameCount".Translate((group.pinned ? "* " : "") + group.name, groupMods.Count));
                if (Widgets.ButtonText(renameRect, "MG_Rename".Translate()))
                {
                    renamingGroupName = group.name;
                    renameBuffer = group.name;
                }
                if (Widgets.ButtonText(deleteRect, "MG_Delete".Translate()))
                {
                    settings.groups.Remove(group);
                    settings.Save();
                }
            }

            y += 32f;

            if (!group.collapsed)
            {
                foreach (var mod in groupMods.OrderBy(m => m.Name))
                {
                    y = DrawModRow(width, y, mod, group, settings);
                }
            }

            return y + 8f;
        }

        public static Color GroupColor(ModGroup group)
        {
            Color color;
            if (group != null && !string.IsNullOrEmpty(group.colorHex) && ColorUtility.TryParseHtmlString(group.colorHex, out color))
            {
                color.a = 0.72f;
                return color;
            }
            return new Color(0.22f, 0.22f, 0.22f, 0.6f);
        }

        private float DrawUngrouped(float width, float y, List<ModMetaData> mods, ModGroupsSettings settings)
        {
            Rect headerRect = new Rect(0f, y, width, 30f);
            Widgets.DrawBoxSolid(headerRect, new Color(0.15f, 0.15f, 0.15f, 0.5f));

            Rect collapseRect = new Rect(4f, y + 1f, 24f, 28f);
            if (Widgets.ButtonText(collapseRect, ungroupedCollapsed ? "+" : "-"))
            {
                ungroupedCollapsed = !ungroupedCollapsed;
            }

            Rect nameRect = new Rect(32f, y, width - 32f, 30f);
            Widgets.Label(nameRect, "MG_UngroupedCount".Translate(mods.Count));

            y += 32f;

            if (!ungroupedCollapsed)
            {
                foreach (var mod in mods)
                {
                    y = DrawModRow(width, y, mod, null, settings);
                }
            }

            return y + 8f;
        }

        private float DrawModRow(float width, float y, ModMetaData mod, ModGroup currentGroup, ModGroupsSettings settings)
        {
            Rect rowRect = new Rect(24f, y, width - 24f, 28f);

            // Selection checkbox (for bulk "Add selected to..")
            Rect selectRect = new Rect(rowRect.x, rowRect.y + 5f, 18f, 18f);
            bool isSelected = selected.Contains(mod.PackageId);
            bool newSelected = isSelected;
            Widgets.Checkbox(new Vector2(selectRect.x, selectRect.y), ref newSelected);
            if (newSelected != isSelected)
            {
                if (newSelected) selected.Add(mod.PackageId);
                else selected.Remove(mod.PackageId);
            }

            // Active/enabled checkbox
            Rect checkRect = new Rect(rowRect.x + 24f, rowRect.y + 5f, 18f, 18f);
            bool active = mod.Active;
            bool newActive = active;
            Widgets.Checkbox(new Vector2(checkRect.x, checkRect.y), ref newActive);
            if (newActive != active)
            {
                mod.Active = newActive;
                ModsConfig.Save();
            }

            const float moveButtonWidth = 150f;
            Rect labelRect = new Rect(rowRect.x + 48f, rowRect.y, rowRect.width - 48f - moveButtonWidth - 8f, 28f);
            Widgets.Label(labelRect, mod.Name);

            Rect moveRect = new Rect(rowRect.xMax - moveButtonWidth, rowRect.y + 1f, moveButtonWidth, 26f);
            if (Widgets.ButtonText(moveRect, "MG_AddToGroup".Translate()))
            {
                var options = new List<FloatMenuOption>();
                foreach (var g in settings.groups)
                {
                    if (g.packageIds.Contains(mod.PackageId)) continue; // already in this group
                    options.Add(new FloatMenuOption(g.name, () =>
                    {
                        g.packageIds.Add(mod.PackageId);
                        if (!settings.knownPackageIds.Contains(mod.PackageId))
                        {
                            settings.knownPackageIds.Add(mod.PackageId);
                        }
                        settings.Save();
                    }));
                }
                if (currentGroup != null)
                {
                    options.Add(new FloatMenuOption("MG_RemoveFromThisGroup".Translate(), () =>
                    {
                        currentGroup.packageIds.Remove(mod.PackageId);
                        settings.Save();
                    }));
                }
                if (options.Count == 0)
                {
                    options.Add(new FloatMenuOption("MG_CreateGroupFirst".Translate(), null));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }

            return y + 28f;
        }
    }
}
