using System.Collections.Generic;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Persisted via RimWorld's ModSettings mechanism, which writes to
    /// Config/ModGroups_ModGroupsSettings.xml — independent of any save game,
    /// so groups persist across every playthrough.
    /// </summary>
    public class ModGroupsSettings : ModSettings
    {
        public List<ModGroup> groups = new List<ModGroup>();

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref groups, "groups", LookMode.Deep);

            if (groups == null)
            {
                groups = new List<ModGroup>();
            }
        }

        public void Save()
        {
            Write();
        }
    }
}
