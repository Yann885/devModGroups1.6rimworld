using System.Collections.Generic;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// Persisted via RimWorld's ModSettings mechanism, which writes to
    /// Config/ModGroups_ModGroupsSettings.xml — independent of any save game,
    /// so groups persist across every playthrough.
    /// </summary>
    public class ModGroupsSettings : ModSettings
    {
        public List<ModGroup> groups = new List<ModGroup>();

        // Every packageId we've ever "shown" the player in the New mods
        // section. Anything installed that's NOT in here yet is treated as
        // newly appeared (e.g. subscribed on Steam since you last opened
        // this window) and surfaced in its own section.
        public List<string> knownPackageIds = new List<string>();

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref groups, "groups", LookMode.Deep);
            Scribe_Collections.Look(ref knownPackageIds, "knownPackageIds", LookMode.Value);

            if (groups == null)
            {
                groups = new List<ModGroup>();
            }
            if (knownPackageIds == null)
            {
                knownPackageIds = new List<string>();
            }
        }

        public void Save()
        {
            Write();
        }
    }
}
