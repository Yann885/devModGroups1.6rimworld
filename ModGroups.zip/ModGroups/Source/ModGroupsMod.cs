using System;
using HarmonyLib;
using UnityEngine;
using Verse;

namespace ModGroups
{
    public class ModGroupsMod : Mod
    {
        public static ModGroupsSettings Settings;
        public static ModGroupsMod Instance;

        public ModGroupsMod(ModContentPack content) : base(content)
        {
            Instance = this;
            Settings = GetSettings<ModGroupsSettings>();

            try
            {
                var harmony = new Harmony("dmitri.modgroups");
                harmony.PatchAll();
            }
            catch (Exception ex)
            {
                // Don't let a patching failure take down the whole mod's
                // instantiation - log it clearly instead so the rest of the
                // mod list still loads and we get a readable error.
                Log.Error($"[Mod Groups] Failed to apply Harmony patches: {ex}");
            }
        }

        public override string SettingsCategory()
        {
            return "Mod Groups";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            var listing = new Listing_Standard();
            listing.Begin(inRect);
            listing.Label("Manage your groups from the \"Mod Groups\" button on the mod list screen.");
            listing.Gap();
            listing.Label($"Groups currently saved: {Settings.groups.Count}");
            listing.End();
            base.DoSettingsWindowContents(inRect);
        }

        public override void WriteSettings()
        {
            base.WriteSettings();
        }
    }
}
