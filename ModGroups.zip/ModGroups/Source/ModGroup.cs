using System.Collections.Generic;
using Verse;

namespace ModGroups
{
    /// <summary>
    /// A single user-created group: a name, the set of mod packageIds it contains,
    /// and whether it's currently collapsed in the UI.
    /// </summary>
    public class ModGroup : IExposable
    {
        public string name;
        public List<string> packageIds = new List<string>();
        public bool collapsed = false;

        // Parameterless constructor required by Scribe for deserialization.
        public ModGroup()
        {
        }

        public ModGroup(string name)
        {
            this.name = name;
        }

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Collections.Look(ref packageIds, "packageIds", LookMode.Value);
            Scribe_Values.Look(ref collapsed, "collapsed", false);

            if (packageIds == null)
            {
                packageIds = new List<string>();
            }
        }
    }
}
